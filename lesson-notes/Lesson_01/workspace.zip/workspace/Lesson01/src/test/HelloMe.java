package test;

public class HelloMe {

	public static void main(String[] args) {
		System.out.println("Hello me 2017!");
		System.out.println("Hello me 2017!");
		System.out.println("Hello me 2017!");
		System.out.println("Hello me 2017!");
	}

}
