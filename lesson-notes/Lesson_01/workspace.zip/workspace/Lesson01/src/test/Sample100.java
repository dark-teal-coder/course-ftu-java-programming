package test;

public class Sample100 {

	public static void main(String[] args) {
		System.out.println("Show me some \'Special\' item.");
		System.out.println("The following data:\n123 for everyone.");

		System.out.println("Oct Code:123 is: \123 character.");
		System.out.println("Hex Code:0097 is: \u0097 character.");

		System.out.print("Same line with the following message: ");
		System.out.print("Hello 2014!");

	}

}
