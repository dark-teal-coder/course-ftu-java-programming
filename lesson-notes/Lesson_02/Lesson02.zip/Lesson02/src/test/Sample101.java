package test;

public class Sample101 {

  public static void main(String[] args) {
    String staffName = "David Ng";
    int staffAge = 36;
    double salary;

    System.out.println("Staff Name:" + staffName);
    System.out.println("Age:" + staffAge);
    
    salary = 13050.5;
    System.out.println(salary);
    
    salary = 18000;
    System.out.println(salary);
  }

}
