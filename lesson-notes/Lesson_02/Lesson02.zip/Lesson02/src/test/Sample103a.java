package test;

public class Sample103a {

  public static void main(String[] args) {

    String a = "JS ";
    String b = "Code: ";

    int pdata = 35;
    int sdata = 123;
    System.out.println(a + b + pdata + sdata);

    int xdata = pdata + sdata;
    System.out.println(a + b + xdata);
    
  }

}
