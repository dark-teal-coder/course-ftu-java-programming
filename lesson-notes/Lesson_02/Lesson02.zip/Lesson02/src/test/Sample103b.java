package test;

public class Sample103b {

  public static void main(String[] args) {

    int pdata = 35;
    int sdata = 123; 
    
    pdata += 35;
    sdata -= 23;
    
    System.out.println("pdata = " + pdata);
    System.out.println("sdata = " + sdata);

  }

}
